﻿namespace IRunes.Services.Contracts
{
    public interface IHashService
    {
        string Hash(string hashToString);
    }
}