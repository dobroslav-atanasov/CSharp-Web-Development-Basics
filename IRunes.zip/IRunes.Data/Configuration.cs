﻿namespace IRunes.Data
{
    internal class Configuration
    {
        internal const string ConnectionString = @"Server=.;Database=IRunes;Integrated Security=True";
    }
}