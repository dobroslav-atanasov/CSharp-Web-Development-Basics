﻿namespace SIS.HTTP.Enums
{
    public enum HttpRequestMethod
    {
        Get,
        Post,
        Put,
        Delete
    }
}